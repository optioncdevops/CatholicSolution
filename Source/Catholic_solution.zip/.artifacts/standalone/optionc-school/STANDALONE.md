# optionc-school standalone deployment

This folder is generated from the Catholic Solutions monorepo and is self-contained for this SaaS domain.

## Run

```bash
npm install
npm run dev
```

Open `http://localhost:4002`. If there is no development session, the solution redirects to the central Login domain defined in `src/shared/auth/appAuthConfig.ts` and returns here after authentication. The Central Login application must be available for an unauthenticated browser session.

## Build

```bash
npm run build:staging
npm run build:production
```

Deploy the generated `dist/` folder to this solution's configured domain.

Do not manually edit `src/shared`; regenerate this standalone package from the monorepo when common platform code changes.
