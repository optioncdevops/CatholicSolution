export { OptionCSchoolPage } from './OptionCSchoolPage';
