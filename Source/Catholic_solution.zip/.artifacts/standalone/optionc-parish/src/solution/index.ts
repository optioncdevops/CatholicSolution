export { OptionCParishPage } from './OptionCParishPage';
