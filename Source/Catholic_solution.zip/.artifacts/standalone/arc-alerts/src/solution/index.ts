export { ArcAlertsPage } from './ArcAlertsPage';
