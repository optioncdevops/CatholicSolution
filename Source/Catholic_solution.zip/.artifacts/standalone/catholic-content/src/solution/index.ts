export { CatholicContentPage } from './CatholicContentPage';
