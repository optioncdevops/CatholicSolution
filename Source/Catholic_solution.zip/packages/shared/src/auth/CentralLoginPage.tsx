import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useToast } from '@shared/app/components/ToastProvider';
import { ArrowRightIcon, EyeIcon, EyeOffIcon, LockIcon, MailIcon } from '@shared/app/components/UiIcons';
import { PlatformLink } from '@shared/platform/navigation/PlatformLink';
import { environment } from '@shared/platform/config/environment';
import { SOLUTION_REGISTRY } from '@shared/platform/config/solutionRegistry';
import { AuthShell } from './AuthShell';
import { useAuth } from './AuthProvider';
import { getRequestedClientId, getSafeReturnUrl, toAbsoluteReturnUrl } from './centralAuth';

function isAbsolute(value: string) {
  return /^https?:\/\//i.test(value);
}

export function CentralLoginPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const clientId = useMemo(() => getRequestedClientId(location.search), [location.search]);
  const destination = useMemo(() => getSafeReturnUrl(location.search, '/apps'), [location.search]);
  const requiresInteractiveSignIn = useMemo(() => {
    const params = new URLSearchParams(location.search);
    return clientId === 'platform' && params.get('entry') === 'platform';
  }, [clientId, location.search]);
  const client = SOLUTION_REGISTRY[clientId];
  const { isAuthenticated, signIn } = useAuth();
  const { showToast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [interactiveSignInCompleted, setInteractiveSignInCompleted] = useState(false);
  const [remember, setRemember] = useState(true);
  const [email, setEmail] = useState(environment.authMode === 'mock' ? 'carl.lapp@optionc.com' : '');
  const [password, setPassword] = useState(environment.authMode === 'mock' ? 'demo1234' : '');

  const completeCentralReturn = useCallback(() => {
    if (!isAbsolute(destination)) {
      navigate(destination, { replace: true });
      return;
    }
    window.location.replace(destination);
  }, [destination, navigate]);

  useEffect(() => {
    if (isAuthenticated && (!requiresInteractiveSignIn || interactiveSignInCompleted)) {
      completeCentralReturn();
    }
  }, [completeCentralReturn, interactiveSignInCompleted, isAuthenticated, requiresInteractiveSignIn]);

  const completeSignIn = async (provider: 'password' | 'google' | 'microsoft') => {
    const result = await signIn({
      email,
      password,
      remember,
      provider,
      clientId,
      returnUrl: toAbsoluteReturnUrl(destination),
    });
    if (result === 'authenticated') {
      setInteractiveSignInCompleted(true);
      showToast(clientId === 'platform' ? 'Signed in to Catholic Solutions' : `Signed in. Returning to ${client.name}`);
    } else if (result === 'unavailable') {
      showToast('The configured identity service is unavailable. Please contact your administrator.');
    }
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    void completeSignIn('password');
  };

  return (
    <AuthShell solutionId="platform">
      <div className="auth-login-stack">
        <section className="auth-card auth-login-card">
          <div className="auth-card__header">
            <span className="auth-card__kicker">Central member sign in</span>
            <h2>Welcome back</h2>
            <p>{clientId === 'platform' ? 'Sign in to continue to your Catholic Solutions workspace.' : `Sign in once to continue securely to ${client.name}.`}</p>
          </div>

          <form onSubmit={submit} className="auth-form">
            <div>
              <label className="auth-label" htmlFor="email">Email address</label>
              <div className="auth-input-wrap mt-1.5">
                <span className="auth-input-icon"><MailIcon size={16} /></span>
                <input id="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="auth-input" autoComplete="email" required />
              </div>
            </div>

            <div>
              <div className="auth-label-row">
                <label className="auth-label" htmlFor="password">Password</label>
                <PlatformLink to={`/forgot-password${location.search}`} className="auth-text-link">Forgot password?</PlatformLink>
              </div>
              <div className="auth-input-wrap mt-1.5">
                <span className="auth-input-icon"><LockIcon size={16} /></span>
                <input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className="auth-input auth-input--with-action" autoComplete="current-password" required />
                <button type="button" onClick={() => setShowPassword((value) => !value)} className="auth-input-action" aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? <EyeOffIcon size={17} /> : <EyeIcon size={17} />}</button>
              </div>
            </div>

            <label className="auth-checkbox auth-checkbox--login"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} /> <span>Keep me signed in on this device</span></label>

            <button type="submit" className="auth-primary-button auth-primary-button--large">Sign in securely <ArrowRightIcon size={16} /></button>

            <div className="auth-divider"><span>Or continue with</span></div>
            <div className="auth-sso-grid">
              <button type="button" onClick={() => void completeSignIn('google')} className="auth-sso-button"><span className="auth-google-mark">G</span><span>Google</span></button>
              <button type="button" onClick={() => void completeSignIn('microsoft')} className="auth-sso-button"><span className="auth-microsoft-mark" aria-hidden="true"><i/><i/><i/><i/></span><span>Microsoft</span></button>
            </div>
          </form>
        </section>

        <section className="auth-access-callout auth-access-callout--compact">
          <div className="auth-access-callout__copy"><strong>New to Catholic Solutions?</strong><span>Request organization access.</span></div>
          <PlatformLink to="/request-access" className="auth-access-callout__action">Request access <ArrowRightIcon size={15} /></PlatformLink>
        </section>

        {/* {environment.authMode === 'mock' ? <p className="auth-prototype-note">Development authentication · Central preview session is enabled.</p> : null} */}
      </div>
    </AuthShell>
  );
}
