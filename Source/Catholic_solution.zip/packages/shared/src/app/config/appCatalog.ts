import type { CatalogApp } from '@shared/app/types/app';

export const APP_CATALOG: CatalogApp[] = [
  {
    id: "optionc-school", name: "OptionC School", shortName: "School", category: "Student Information System",
    description: "Comprehensive student information and academic management — attendance, gradebook, report cards and a parent portal in one place.",
    icon: "🎓", gradient: "linear-gradient(135deg,#1E3A8A,#3B82F6)",
    route: "/",
    keywords: ["school", "student", "information", "academic", "attendance", "gradebook"],
    features: ["✅ Attendance", "📊 Gradebook", "📄 Report cards", "👨‍👩‍👧 Parent portal"],
    stats: [{ value: "842", label: "Students synced" }, { value: "46", label: "Staff accounts" }, { value: "3", label: "Approvals pending" }, { value: "v4.2", label: "Updated Jul 2026" }],
    kind: "launchable", status: "active", statusLabel: "Active",
    statusDetail: "● Active · Last used today 9:14 AM",
    details: {
      longDescription: "OptionC School is the system of record for every student and staff member across your campus. Teachers take attendance and enter grades from any device, front-office staff manage admissions and records, and parents get a live portal for grades, attendance and announcements — all synced in real time.",
      included: ["Daily attendance with automatic absence alerts to parents", "Standards-based or traditional gradebook with report-card generation", "Parent & student portal with grades, homework and school news", "Admissions workflow from application through enrollment", "Role-based access for teachers, office staff and administrators"],
      integrations: ["💰 Matt Money", "✅ AI Attendance Taker", "🔔 ArcAlerts"],
      activity: [{ title: "New admission approved — Vikram R, Grade 6", meta: "Today, 9:14 AM" }, { title: "Report cards published — Grade 9B", meta: "Yesterday, 4:02 PM" }, { title: "Attendance sync completed — all campuses", meta: "Yesterday, 8:00 AM" }],
    },
  },
  {
    id: "matt-money", name: "Matt Money", shortName: "Matt Money", category: "Billing & Finance",
    description: "Seamless online payment processing and financial tracking — tuition billing, donations and automatic reconciliation. PCI-DSS compliant.",
    icon: "💰", gradient: "linear-gradient(135deg,#0F766E,#34D399)",
    route: "/",
    keywords: ["billing", "payment", "finance", "tuition", "donation", "reconciliation"],
    features: ["💳 Online payments", "🧾 Tuition billing", "🤲 Donations", "🔄 Auto-reconcile"],
    stats: [{ value: "$1.21M", label: "Collected this month" }, { value: "63", label: "Fees pending" }, { value: "5", label: "Approvals waiting" }, { value: "PCI-DSS", label: "Compliant" }],
    kind: "launchable", status: "active", statusLabel: "Active",
    statusDetail: "● Active · Last used 2 hrs ago",
    details: {
      longDescription: "Matt Money handles every dollar moving through your school and parish — tuition invoicing, online payments, donation processing and expense approvals — with automatic bank reconciliation so your books stay accurate without manual entry.",
      included: ["Online tuition billing with auto-pay and payment plans", "One-tap donation and offertory processing", "Expense submission and multi-level approval workflow", "Automatic bank reconciliation and monthly close reports", "PCI-DSS compliant payment handling"],
      integrations: ["🎓 OptionC School", "✝️ Parish Hub", "📊 Financial Needs Assessment"],
      activity: [{ title: "Term 1 tuition batch received — $450,000", meta: "Today, 7:40 AM" }, { title: "Expense approved — Building rent", meta: "Yesterday, 3:15 PM" }, { title: "Monthly reconciliation completed", meta: "Aug 4, 6:00 AM" }],
    },
  },
  {
    id: "arc-alerts", name: "ArcAlerts", shortName: "ArcAlerts", category: "Emergency Communication",
    description: "Instant multi-channel notifications via text, email, and voicemail — reach every parent, staff member and parishioner in under a minute.",
    icon: "🔔", gradient: "linear-gradient(135deg,#B91C1C,#EF4444)",
    route: "/",
    keywords: ["alerts", "notification", "text", "email", "voicemail", "emergency"],
    features: ["📱 Text", "📧 Email", "📞 Voicemail", "📋 Templates"],
    stats: [{ value: "2,340", label: "Reachable contacts" }, { value: "98.6%", label: "Delivery rate" }, { value: "42 sec", label: "Avg delivery" }, { value: "Aug 15", label: "Next drill" }],
    kind: "launchable", status: "all-clear", statusLabel: "All clear",
    statusDetail: "● All clear · Monitoring live",
    details: {
      longDescription: "ArcAlerts is your emergency notification system — send one message and reach every parent, staff member and parishioner across text, email and voicemail in under a minute. Built for weather closures, safety incidents, and everyday schedule notices alike.",
      included: ["Multi-channel delivery — text, email and voicemail, simultaneously", "Pre-built templates for weather, safety and schedule alerts", "Live delivery tracking with per-channel success rates", "Group targeting — by campus, grade, class or role", "Scheduled drills and delivery-rate reporting"],
      integrations: ["🎓 OptionC School", "✝️ Parish Hub", "🤝 Vincent Volunteer"],
      activity: [{ title: "Storm alert sent — early dismissal", meta: "Aug 1, 2:12 PM · 2,310 delivered" }, { title: "Feast day schedule notice sent", meta: "Jul 28, 9:00 AM · 2,150 delivered" }, { title: "Monthly safety drill scheduled", meta: "Aug 15, 10:00 AM" }],
    },
  },
  {
    id: "optionc-parish", name: "Parish Hub", shortName: "Parish", category: "Parish Administration",
    description: "Integrated tools to manage your parish community and sacraments — family records, sacrament registers and Mass intentions.",
    icon: "✝️", gradient: "linear-gradient(135deg,#166534,#22C55E)",
    route: "/",
    keywords: ["parish", "sacraments", "family", "mass", "giving"],
    features: ["✝️ Sacrament records", "👪 Family directory", "🕯️ Mass intentions", "📜 Certificates"],
    stats: [{ value: "486", label: "Registered families" }, { value: "12", label: "Open requests" }, { value: "9", label: "Completed this month" }, { value: "Diocese", label: "Approved registers" }],
    kind: "launchable", status: "active", statusLabel: "Active",
    statusDetail: "● Active · Last used today 8:02 AM",
    details: {
      longDescription: "Parish Hub keeps every family, sacrament and Mass intention organized in diocese-approved registers. Track requests from first enquiry through completion, manage the Mass schedule, and see offertory and giving trends alongside your sacrament records.",
      included: ["Family directory with household and contact records", "Sacrament registers — baptism, communion, confirmation, marriage", "Request board tracking enquiry through completion", "Mass schedule and intention booking", "Offertory & giving reports"],
      integrations: ["💰 Matt Money", "🗓️ Berchmans", "🔔 ArcAlerts"],
      activity: [{ title: "Baptism completed — Rodrigues family", meta: "Aug 2 · Certificate issued" }, { title: "Confirmation rehearsal scheduled", meta: "Aug 9, 5:00 PM" }, { title: "House blessing confirmed — Fernandes family", meta: "Aug 9, 4:30 PM" }],
    },
  },
  {
    id: "catholic-content", name: "Catholic Content", shortName: "Content", category: "Faith Resources",
    description: "Over 1,600 faith-based resources including workbooks, coloring pages, and more — searchable by grade, season and topic.",
    icon: "📚", gradient: "linear-gradient(135deg,#5B21B6,#8B5CF6)",
    route: "/",
    keywords: ["content", "saints", "resources", "workbooks", "faith"],
    features: ["📘 Workbooks", "🖍️ Coloring pages", "🎬 Videos", "🔍 Search by grade"],
    stats: [{ value: "1,200+", label: "Learning resources" }, { value: "Daily", label: "Saints of the day" }, { value: "9", label: "Categories" }, { value: "Included", label: "With subscription" }],
    kind: "launchable", status: "active", statusLabel: "Active",
    statusDetail: "● Active · Resource library",
    details: {
      longDescription: "Catholic Content is a searchable library of faith-based curriculum resources — coloring pages, word searches, workbooks and more — with a new Saint of the Day resource added automatically. Everything is organized by grade, saint, season and content type so teachers can find what they need in seconds.",
      included: ["1,200+ resources with new additions tied to current Church events", "Saints of the Day, organized by month", "Nine searchable categories including Prayers, Workbooks and Feasts", "Built-in document viewer with zoom, print and download", "Rights-managed content licensed for classroom and homework use"],
      integrations: ["🎓 OptionC School", "🧠 Friar Friend"],
      activity: [{ title: "Saint Hormisdas, Pope resource added", meta: "Today" }, { title: "Saint Afra resources added", meta: "Aug 5" }, { title: "New feast-day collection published", meta: "Aug 1" }],
    },
  },
  {
    id: "unified-directory", name: "Unified Directory", shortName: "Directory", category: "Identity & Access",
    description: "Add and manage people and groups across Catholic Solutions from one shared organization directory.",
    icon: "👥", gradient: "linear-gradient(135deg,#075985,#0EA5E9)",
    route: "/",
    keywords: ["directory", "users", "groups", "identity", "access", "people"],
    features: ["👤 Active / inactive users", "🧩 SaaS app access", "👥 Groups", "🔐 Membership management"],
    stats: [{ value: "132", label: "Directory users" }, { value: "117", label: "Active users" }, { value: "12", label: "Groups configured" }, { value: "2", label: "Apps provisionable" }],
    kind: "launchable", status: "active", statusLabel: "Active",
    statusDetail: "● Active · Organization directory",
    details: {
      longDescription: "Unified Directory is the shared people, SaaS-access, and group layer for Catholic Solutions. Administrators can manage active and inactive users, assign application access, maintain group membership, and review each identity from one scalable directory workspace.",
      included: ["Active and inactive user workspaces with 100+ directory identities", "Matt Money and ArcAlerts access captured when a user is added", "Reusable groups with direct member management", "Search and filter by user, email, application, or group", "Scrollable grids, Print/CSV export, and a dedicated detail panel"],
      integrations: ["🎓 OptionC School", "✝️ Parish Hub", "🤝 Vincent Volunteer", "🔔 ArcAlerts"],
      activity: [{ title: "Volunteer Coordinators group updated", meta: "Today" }, { title: "Anna Rodrigues added", meta: "Yesterday" }, { title: "Faculty membership synchronized", meta: "Aug 6" }],
    },
  },
  {
    id: "support-center", name: "Support Center", shortName: "Support", category: "Member Services",
    description: "Submit support tickets and keep the complete conversation history for every Catholic Solutions request in one workspace.",
    icon: "🛟", gradient: "linear-gradient(135deg,#164E63,#0E7490)",
    route: "/", navigationTarget: "same-tab",
    keywords: ["support", "help", "ticket", "resources", "member services", "contact"],
    features: ["🎫 Ticket inbox", "💬 Conversation history", "📎 Attachments", "🧭 Product routing"],
    stats: [{ value: "3", label: "Sample tickets" }, { value: "9", label: "Conversation entries" }, { value: "1 day", label: "Typical response" }, { value: "12", label: "Products supported" }],
    kind: "launchable", status: "active", statusLabel: "Active",
    statusDetail: "● Active · Member Services available",
    details: {
      longDescription: "Support Center brings Catholic Solutions ticket management into one shared workspace. Staff can create a product-routed request, select any existing ticket to read the complete support conversation, reply in context, and return to a fresh ticket form without leaving the page.",
      included: ["Full-width ticket inbox and conversation workspace", "Complete per-ticket conversation history", "Support-ticket form with product and contact-team routing", "Attachment entry point for screenshots or supporting files", "Member Services route for organization-wide or account questions"],
      integrations: ["🎓 OptionC School", "💰 Matt Money", "🔔 ArcAlerts", "✝️ Parish Hub", "📚 Catholic Content", "👥 Unified Directory", "🤝 Vincent Volunteer"],
      activity: [{ title: "My Classes support ticket opened", meta: "Today" }, { title: "ArcAlerts delivery question awaiting reply", meta: "Yesterday" }, { title: "Directory export request resolved", meta: "Aug 5" }],
    },
  },
  {
    id: "ai-website-builder", name: "AI Website Builder", shortName: "Website Builder", category: "AI · Web Presence",
    description: "Custom built, responsive design school and parish web presence — describe your community and get a polished site with hosting included.",
    icon: "🌐", gradient: "linear-gradient(135deg,#1D4ED8,#38BDF8)",
    keywords: ["ai", "website", "school", "parish", "hosting"],
    features: ["🎨 Custom design", "📱 Mobile-ready", "☁️ Hosting included", "📰 News & bulletins"],
    stats: [{ value: "< 1 day", label: "To launch a site" }, { value: "0", label: "Coding required" }, { value: "100%", label: "Responsive" }, { value: "Demo", label: "Sites available" }],
    kind: "ai", status: "ai-powered", statusLabel: "AI powered",
    statusDetail: "✦ AI powered · Demos available",
    details: {
      longDescription: "Describe your school or parish and get a complete, responsive website back — pages, navigation, and design included — with hosting handled for you. Update news, bulletins and staff listings yourself with no code and no developer needed.",
      included: ["Custom design generated from a short description", "Fully responsive on desktop, tablet and mobile", "Hosting, domain connection and SSL included", "Built-in news, bulletin and staff-directory pages", "No coding required to launch or maintain"],
      integrations: ["✝️ Parish Hub", "🎓 OptionC School"],
      steps: ["Request access from your administrator", "Describe your school or parish community", "Review your generated site and go live"],
    },
  },
  {
    id: "ai-lesson-plan", name: "AI Lesson Plan Generator", shortName: "Lesson Plans", category: "AI · Teaching",
    description: "Open the current XtraCoach lesson-planning experience while the Catholic Solutions native workspace remains under review.",
    icon: "📝", gradient: "linear-gradient(135deg,#D97706,#FBBF24)",
    externalUrl: "https://demo.optionc.com/XtraCoach", navigationTarget: "new-tab",
    keywords: ["lesson plan", "teacher", "planning", "xtracoach"],
    features: ["📝 Lesson planning", "✨ XtraCoach", "📚 Teaching workflow"],
    stats: [],
    kind: "external", status: "available", statusLabel: "Open XtraCoach", statusDetail: "Opens XtraCoach in a new tab",
    details: {
      longDescription: "AI Lesson Plan Generator currently opens the approved XtraCoach lesson-planning experience in a separate browser tab. The native Catholic Solutions lesson-plan workspace is retained only as an implementation prototype and is not the active product destination.",
      included: ["Current XtraCoach lesson-planning experience", "Separate-tab launch that keeps Catholic Solutions open", "Existing XtraCoach teaching workflow"],
      integrations: ["🎓 OptionC School", "📚 Catholic Content"],
    },
  },
  {
    id: "ai-attendance", name: "AI Attendance Taker", shortName: "Attendance", category: "AI · Classroom",
    description: "A faster way to automate attendance powered by AI — take the roll in seconds and sync results straight into OptionC School.",
    icon: "✅", gradient: "linear-gradient(135deg,#2563EB,#60A5FA)",
    keywords: ["ai", "attendance", "classroom"],
    features: ["⚡ Seconds per class", "🔄 Syncs to OptionC School", "📊 Absence trends"],
    stats: [{ value: "Seconds", label: "Per class" }, { value: "Auto-sync", label: "To OptionC School" }, { value: "Privacy", label: "First design" }, { value: "Early", label: "Access" }],
    kind: "ai", status: "ai-powered", statusLabel: "AI powered",
    statusDetail: "✦ AI powered · Early access",
    details: {
      longDescription: "Take attendance for an entire class in seconds instead of minutes — results sync automatically into OptionC School's gradebook and attendance records, with absence-trend insights surfaced for teachers and administrators.",
      included: ["Class-wide attendance captured in seconds", "Automatic sync to OptionC School records", "Absence-trend insights for teachers and admins", "Privacy-first design — no data leaves your account", "Early-access pricing for founding schools"],
      integrations: ["🎓 OptionC School"],
      steps: ["Request early access from your administrator", "Connect to your OptionC School classes", "Start taking attendance in seconds"],
    },
  },
  {
    id: "financial-needs", name: "Financial Needs Assessment", shortName: "Needs Assessment", category: "Tuition Assistance",
    description: "A research initiative to build fair, transparent tuition assistance tools — assess need consistently and award aid with confidence.",
    icon: "📊", gradient: "linear-gradient(135deg,#0369A1,#38BDF8)",
    keywords: ["financial", "needs", "tuition", "assistance"],
    features: ["⚖️ Fair & transparent", "🧮 Need scoring", "🔒 Private & secure"],
    stats: [{ value: "Research", label: "Backed model" }, { value: "Consistent", label: "Need scoring" }, { value: "Works with", label: "Matt Money" }, { value: "Secure", label: "& private" }],
    kind: "discover", status: "available", statusLabel: "Available",
    statusDetail: "Available to add",
    details: {
      longDescription: "A research-backed tool for evaluating tuition-assistance applications consistently and fairly. Families submit financial information securely, and administrators get a standardized need score to guide awards — removing guesswork and bias from the process.",
      included: ["Secure online application for families", "Standardized, research-backed need scoring", "Consistent criteria across every applicant", "Award tracking synced with Matt Money billing", "Private and confidential by design"],
      integrations: ["💰 Matt Money", "🎓 OptionC School"],
      steps: ["Request access from your administrator", "Set your assistance budget and criteria", "Open applications to families"],
    },
  },
  {
    id: "camp-finder", name: "Catholic Camp Finder", shortName: "Camp Finder", category: "Community",
    description: "Discover and connect with Catholic summer camps nationwide — filter by age, dates, location and camp type.",
    icon: "⛺", gradient: "linear-gradient(135deg,#151032,#4E4870)",
    keywords: ["camp", "summer", "catholic", "directory"],
    features: ["🗺️ Nationwide", "🎯 Filter by age", "📅 Date search", "✉️ Direct enquiries"],
    stats: [{ value: "100s", label: "Camps listed" }, { value: "Filters", label: "Age, date, place" }, { value: "Direct", label: "Enquiries" }, { value: "Family", label: "Friendly" }],
    kind: "discover", status: "available", statusLabel: "Available",
    statusDetail: "Available to add",
    details: {
      longDescription: "A nationwide directory of Catholic summer camps that families can search and filter directly from your parish or school portal — by age group, dates and location — with enquiries routed straight to each camp.",
      included: ["Nationwide directory of Catholic-affiliated camps", "Filter by age, dates, location and camp type", "Direct enquiry forms to each camp", "Family-friendly browsing experience", "Regularly updated camp listings"],
      integrations: ["✝️ Parish Hub", "🎓 OptionC School"],
      steps: ["Request access from your administrator", "Share the directory link with families", "Families search, filter and enquire directly"],
    },
  },

  // Partner products hosted outside the Catholic Solutions SSO boundary. Navigation behavior is
  // explicit metadata: only approved partner destinations use `new-tab`; all unspecified apps default
  // to same-tab navigation. Entries
  // deliberately carry no fabricated usage metrics or feature detail. An entry without
  // `externalUrl` is not published yet and renders as a non-interactive "Coming soon" card.
  {
    id: "ferrerworks", name: "FerrerWorks", shortName: "FerrerWorks", category: "Facility Management",
    description: "Facility management for school, hall and parish grounds. Opens on the FerrerWorks site.",
    icon: "🏢", gradient: "linear-gradient(135deg,#374151,#6B7280)",
    externalUrl: "https://ferrerworks.com", navigationTarget: "new-tab",
    keywords: ["facility", "management", "rooms", "campus", "maintenance", "ferrerworks"],
    features: ["🏢 Facility management"],
    stats: [],
    kind: "external", status: "available", statusLabel: "Open site",
    statusDetail: "Opens at ferrerworks.com",
  },
  {
    id: "mass-card-requests", name: "Mass Card Requests", shortName: "Mass Cards", category: "Liturgy & Offerings",
    description: "Request and manage Mass cards online. Opens on the MassCardRequests site.",
    icon: "💌", gradient: "linear-gradient(135deg,#9F1239,#F43F5E)",
    externalUrl: "https://masscardrequests.com", navigationTarget: "new-tab",
    keywords: ["mass", "card", "requests", "offering", "intention", "liturgy"],
    features: ["💌 Mass card requests"],
    stats: [],
    kind: "external", status: "available", statusLabel: "Open site",
    statusDetail: "Opens at masscardrequests.com",
  },
  {
    id: "vincent-volunteer", name: "Vincent Volunteer", shortName: "Vincent Volunteer", category: "Service & Community",
    description: "Volunteer coordination for your parish and school community. Opens on the Vincent Volunteer site.",
    icon: "🤝", gradient: "linear-gradient(115deg,#1E2340,#7C2D4B)",
    externalUrl: "https://vincentvolunteer.com", navigationTarget: "new-tab",
    keywords: ["volunteer", "service", "community", "sign-up", "hours", "vincent"],
    features: ["🤝 Volunteer coordination"],
    stats: [],
    kind: "external", status: "available", statusLabel: "Open site",
    statusDetail: "Opens at vincentvolunteer.com",
  },
  {
    id: "berchmans", name: "Berchmans", shortName: "Berchmans", category: "Liturgy",
    description: "Altar server scheduling and assignments. Opens on the Berchmans site.",
    icon: "🗓️", gradient: "linear-gradient(135deg,#15803D,#4ADE80)",
    externalUrl: "https://berchmans.app", navigationTarget: "new-tab",
    keywords: ["altar", "server", "scheduler", "mass", "liturgy", "berchmans"],
    features: ["🗓️ Altar server scheduling"],
    stats: [],
    kind: "external", status: "available", statusLabel: "Open site",
    statusDetail: "Opens at berchmans.app",
  },
  {
    id: "alive-date", name: "Alive Date", shortName: "Alive Date", category: "Records & Directory",
    description: "Check each person's alive date for directory and register upkeep. Opens on the Alive Date site.",
    icon: "📅", gradient: "linear-gradient(135deg,#92400E,#F59E0B)",
    externalUrl: "https://alivedate.com", navigationTarget: "new-tab",
    keywords: ["alive", "date", "records", "register", "directory", "alivedate"],
    features: ["📅 Alive-date lookup"],
    stats: [],
    kind: "external", status: "available", statusLabel: "Open site",
    statusDetail: "Opens at alivedate.com",
  },
  {
    id: "friar-friend", name: "Friar Friend", shortName: "Friar Friend", category: "AI · Teaching",
    description: "AI quiz maker for faith-based teaching. Opens on the Friar Friend site.",
    icon: "🧠", gradient: "linear-gradient(135deg,#EA580C,#FB923C)",
    externalUrl: "https://friarfriend.com", navigationTarget: "new-tab",
    keywords: ["ai", "quiz", "maker", "teaching", "friarfriend"],
    features: ["🧠 AI quiz maker"],
    stats: [],
    kind: "external", status: "available", statusLabel: "Open site",
    statusDetail: "Opens at friarfriend.com",
  },
];

export const launchableApps = APP_CATALOG.filter((app) => app.kind === 'launchable');
/** Partner products opened at their own domain, outside the central-login boundary. */
export const externalApps = APP_CATALOG.filter((app) => app.kind === 'external');
const yourAppIds = new Set(['optionc-school', 'optionc-parish']);
const availableAppIds = new Set(['ferrerworks', 'mass-card-requests', 'vincent-volunteer', 'berchmans', 'alive-date', 'friar-friend']);
/** The App Hub `Your Apps` collection, kept in catalog order. */
export const yourApps = APP_CATALOG.filter((app) => yourAppIds.has(app.id));
/** App Hub partner products available to add or open now. */
export const availableApps = APP_CATALOG.filter((app) => availableAppIds.has(app.id));
/** App Hub products that remain on the roadmap. */
export const futureApps = APP_CATALOG.filter((app) => !yourAppIds.has(app.id) && !availableAppIds.has(app.id));
/** Published destinations that can be opened immediately from the shared switcher. */
export const availableSwitcherApps = [...yourApps, ...availableApps].filter((app) => app.kind === 'launchable' || Boolean(app.externalUrl));
export const aiApps = APP_CATALOG.filter((app) => app.kind === 'ai');
export const discoverApps = APP_CATALOG.filter((app) => app.kind === 'discover');
export const getAppById = (id: string) => APP_CATALOG.find((app) => app.id === id);
/** Central App Hub / switcher launch policy. */
export const appOpensInNewTab = (app: CatalogApp) => app.navigationTarget === 'new-tab';
